# Create: Fueling Imagination 1.2.121

Minecraft 1.20.1 · Forge 47.4.23 · Create 6.0.8

## 安装

1. 把 jar/create-fueling-imagination-1.2.121.jar 放进 .minecraft/mods/
2. 需要已安装 Create 6.0.8-289（及可选：create_jetpack 4.4.6，用于喷气背包改装）
3. 启动游戏

## 内容

- **损坏与维修**：被爆炸打坏的方块可在动力工作站维修（拆解 / 清洁 / 换件 / 重组），或用动力拆解器粉碎回收
- **背罐与喷气背包改装**：护甲槽 + 升级组件 + 鞘翅槽
- **动力集成工具**：材质槽 + 4 个配件槽，耗压缩空气
- **命令方块-携带版** + 8 件具象指令插件
- **放映机**：把文字投射到身前，支持全息 / 影画两种模式
- **进度树**：前辈的笔记，四条支线共 12 个进度

## 源码

src/main/java/com/fuelingimagination，数据在 src/main/resources/data，资源在 src/main/resources/assets。

## 编译

需要 JDK 17：

    ./gradlew build

产物在 build/libs/。