package com.fuelingimagination.item;

import com.fuelingimagination.client.ClientBridge;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * The repair manual: a read-only index of every block the workstation can repair.
 *
 * <p>The list is derived from the item tag on the client, so the book never needs a menu,
 * a packet, or server state. Everything it shows is already synced as part of the tag.
 */
public final class RepairManualItem extends Item {
    public RepairManualItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        // Must test the logical side, not the physical one: in single player the integrated
        // server runs in the same JVM, so FMLEnvironment.dist is CLIENT on both sides and the
        // server thread would try to open a screen. That crashed the game.
        if (level.isClientSide) ClientBridge.openManual();
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
