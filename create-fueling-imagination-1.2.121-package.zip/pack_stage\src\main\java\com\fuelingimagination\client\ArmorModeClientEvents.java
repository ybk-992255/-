package com.fuelingimagination.client;

import com.fuelingimagination.content.armor.ArmorMode;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent.LoggingOut;
import net.minecraftforge.client.event.InputEvent.InteractionKeyMappingTriggered;
import net.minecraftforge.client.event.InputEvent.MouseScrollingEvent;
import net.minecraftforge.client.event.ScreenEvent.Opening;
import net.minecraftforge.event.TickEvent.ClientTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber(
   modid = "fuelingimagination",
   value = {Dist.CLIENT}
)
public final class ArmorModeClientEvents {
   private ArmorModeClientEvents() {
   }

   private static boolean active() {
      return Minecraft.getInstance().player != null && ArmorMode.isActive(Minecraft.getInstance().player);
   }

   private static void drain(KeyMapping key) {
      key.setDown(false);

      while (key.consumeClick()) {
      }
   }

   @SubscribeEvent
   public static void tick(ClientTickEvent event) {
      if (event.phase == Phase.START && active()) {
         Minecraft mc = Minecraft.getInstance();

         for (KeyMapping key : mc.options.keyHotbarSlots) {
            drain(key);
         }

         drain(mc.options.keyInventory);
         drain(mc.options.keySwapOffhand);
         drain(mc.options.keyDrop);
         drain(mc.options.keyPickItem);
         drain(mc.options.keyAttack);
         mc.player.getInventory().selected = ArmorMode.lockedSlot(mc.player);
      }
   }

   @SubscribeEvent
   public static void openScreen(Opening event) {
      if (active() && event.getNewScreen() instanceof AbstractContainerScreen) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void scroll(MouseScrollingEvent event) {
      if (active() && Minecraft.getInstance().screen == null) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void interact(InteractionKeyMappingTriggered event) {
      if (active() && (event.isAttack() || event.isPickBlock())) {
         event.setCanceled(true);
         event.setSwingHand(false);
      }
   }

   @SubscribeEvent
   public static void hand(RenderHandEvent event) {
      if (active()) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void logout(LoggingOut event) {
      ArmorMode.clearClientState();
   }
}
